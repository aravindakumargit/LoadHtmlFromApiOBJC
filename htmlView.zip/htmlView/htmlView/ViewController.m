//
//  ViewController.m
//  htmlView
//
//  Created by cricket21 on 15/03/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSString *url;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     // Do any additional setup after loading the view, typically from a nib.
    url=@"http://api.cricket-21.com/JsonResoruce/T20%20Domestic/541/others.json";
    [self hitserver];
   
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)hitserver{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:@"GET"];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
         NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        NSString *ltvideo=[json objectForKey:@"Tickets"];
          NSLog(@"requestReply: %@", ltvideo);
        dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            dispatch_async(dispatch_get_main_queue(), ^(void){
                [self.webView loadHTMLString:ltvideo baseURL:nil];

            });
        });
    }] resume];
}

@end
